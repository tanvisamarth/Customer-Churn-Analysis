# Project Overview

This project focuses on analyzing customer churn to identify key factors that influence why customers are leaving a telecom company.
The dashboard provides interactive insights that help business teams take data-driven decisions to reduce churn and improve customer retention.

# Objective

To identify the reasons behind customer churn and uncover actionable insights that can help the company:

Increase customer retention

Improve service quality

Design targeted marketing campaigns

Enhance customer satisfaction

# Key Insights

Churn Rate: 27% of total customers have churned.

High-Risk Customers: Customers with monthly contracts and low tenure are more likely to leave.

Dependents & Partners: Customers without dependents or partners show higher churn tendencies.

Tenure Impact: Long-term customers are more loyal and less likely to churn.

Gender Impact: Gender has no significant effect on churn.

#Key Visuals

Donut Chart – Churned vs Active Customers

Bar Chart – Churn by Contract Type

Line Chart – Tenure vs Churn Rate

Tree Map – Internet Service vs Churn

KPI Cards – Total Customers, Churn %, Average Tenure

